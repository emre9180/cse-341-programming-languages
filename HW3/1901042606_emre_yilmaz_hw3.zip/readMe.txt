For Part-1

How to run: There is a makefile in part-1 directory. Only type "make" to the commandline. It creates a file named parser.out, Then you have to type: "./parser.out". It runs the interpreter. You can write the lines.

There is no information that says Part-1 get input file. So, it runs like only interpreter. You enter a line and it says you it is valid and here the result. Or gives syntax error.

For Part-2,

If you want to test it with a file, you have to add the name of the test file's name to the end of line.
I send you an example test file named test.txt, If you want to test that, you should type the command line: clisp gpp_interpreter.lisp test.txt

If you want to test the parser line by line, you must only type: clisp gpp_interpreter.lisp



