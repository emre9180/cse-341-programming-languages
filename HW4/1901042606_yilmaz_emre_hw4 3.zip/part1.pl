:- dynamic student/3.
:- dynamic course/6.
:- dynamic room/5.

room(z23, 200, [9, 10, 11, 12, 14,15,16], [projector, smart_board], handicapped).
room(z06, 190, [14, 15, 16],          [projector], nophandicapped).
room(z10, 95,  [8, 9, 13, 14, 15],    [projector, smart_board],             nophandicapped).

course(cse102, genc, 110, [14, 15, 16], z23, [projector]).
course(cse241, akgul, 140, [8,9], z10, [projector, smart_board]).
course(cse331, kalkan, 100, [10,11, 12], z06, [smart_board]).
course(cse334, bayrakci, 180, [ 14, 15, 16], z23, [projector, smart_board]).
course(cse321, gozupek, 130, [ 14, 15, 16], z10, [projector, smart_board]).

instructor(genc, [cse102], [projector, smart_board]).
instructor(akgul, [cse241], [projector, smart_board]).
instructor(kalkan, [cse331], [projector]).
instructor(bayrakci, [cse334], [projector]).
instructor(gozupek, [cse321], []).

student(1901042606, [cse331, cse334, cse321], nophandicapped).
student(1901042614, [cse241, cse334, cse331], handicapped).
student(1901042601, [cse102, cse241, cse331, cse334, cse321], nophandicapped).
student(1901042623, [cse334], nophandicapped).

% CHeck there is a conflict
check_conflict :-
    course(CourseID1, _, _, Time1, RoomID1,_), 
    course(CourseID2, _, _, Time2, RoomID2,_),
    CourseID1 \= CourseID2, 
    RoomID1 = RoomID2, 
    member(Times, Time1), 
    member(Times, Time2). 




% Check which courses a student can be assigned.
can_student_enroll(StudentID, Rooms) :-
    findall(Room, enrollability(StudentID, Room), Rooms).



%Check which room can be assigned to a given course.
which_room(CourseID, Rooms) :-
    course(CourseID, _, Cap, Hours, _, Req),
    findall(Room, (room(Room, RoomCap, RoomHours, Req, _), RoomCap >= Cap, subset(Hours, RoomHours)), RoomsList),
    sort(RoomsList, Rooms). % to remove duplicates

%Check which room can be assigned to which courses.
find_matches(Matches) :-
    findall((CourseID, Rooms), (course(CourseID, _, Cap, Hours, _, Req), 
                     findall(Room,
                     (room(Room, RoomCap, RoomHours, Req, _),
                      RoomCap >= Cap,
                      subset(Hours, RoomHours)),
                     RoomsList),
             sort(RoomsList, Rooms)),  % to remove duplicates
            Matches).



% Check whether a student can be enrolled to a given course.
enrollability(StudentID, CourseID) :-
    student(StudentID, EnrolledCourses, StudentHandicapped), 
    course(CourseID, _, _, Time, RoomID, _), 
    room(RoomID, _, AvailableTime, _, Handicapped), 
    subset(Time, AvailableTime),
    StudentHandicapped = Handicapped. 


% Check which courses a student can be assigned.
which_course_enroll(StudentID, Rooms) :-
    student(StudentID, Courses, Handicapped),
    findall(Room, enrollability(StudentID, Room), Rooms).


add_student(StudentID, Handicapped):-
    assert(student(StudentID , _, Handicapped)).

add_course(CourseID, Instructor, Cap, Hours, Room, Reqs) :-
    assert(course(CourseID, Instructor, Cap, Hours, Room, [Reqs])).

add_room(RoomID, Capacity, Hours, Equipment, Handicapped):-
    assert(room(RoomID, Capacity, [Hours], [Equipment], Handicapped)).



