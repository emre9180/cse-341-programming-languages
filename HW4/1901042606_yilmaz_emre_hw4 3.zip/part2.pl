schedule(istanbul, izmir, 2).
schedule(izmir, istanbul, 2).

schedule(istanbul, ankara, 1).
schedule(ankara, istanbul, 1).

schedule(istanbul, rize, 4).
schedule(rize, istanbul, 4).

schedule(izmir, ankara, 6).
schedule(ankara, izmir, 6).

schedule(izmir, antalya, 2).
schedule(antalya, izmir, 2).

schedule(ankara, van, 3).
schedule(van, ankara, 3).

schedule(ankara, diyarbakır, 8).
schedule(diyarbakır, ankara, 8).

schedule(van, gaziantep, 3).
schedule(gaziantep, van, 3).

schedule(antalya, diyarbakır, 4).
schedule(diyarbakır, antalya, 4).

schedule(canakkale, erzincan, 6).
schedule(erzincan, canakkale, 6).

schedule(hakkari, canakkale, 60).
schedule(canakkale, hakkari, 60).

schedule(sirnak, gaziantep, 30).
schedule(gaziantep, sirnak, 60).

% there is a connection between X and Y with cost C
connection(X, Y, C) :- schedule(X, Y, C).


% make a list all the cities that X is connected to
connection(X, Y, list) :- findall(City, helper(X, City), Y).

% there is a direct connection between X and Y
helper(X, Y) :- schedule(X, Y, _).
